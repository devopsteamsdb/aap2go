==============================
ansible.platform Release Notes
==============================

.. contents:: Topics

v2.7.20260930
=============

Minor Changes
-------------

- auth - Add inventory variable ``aap_ca_bundle`` (aliases ``gateway_ca_bundle``, ``ansible_platform_ca_bundle``) to supply a control-node CA bundle path for Gateway TLS verification without per-task ``environment:`` blocks. The path is forwarded to manager subprocesses as ``REQUESTS_CA_BUNDLE`` when ``aap_validate_certs`` is enabled.
- role_team_assignment - add optional organization on assignment_objects for org-scoped name lookup (Controller/EDA/teams).
- service_cluster - add ``outlier_detection_split_external_local_origin_errors`` and ``outlier_detection_consecutive_local_origin_failure`` options (https://issues.redhat.com/browse/AAP-76998).

Removed Features (previously deprecated)
----------------------------------------

- role_team_assignment - remove unimplemented object_ids option (never present on stable-2.6; use assignment_objects with object_id).

Bugfixes
--------

- auth - Include the effective CA bundle (shell env, task ``REQUESTS_CA_BUNDLE``, inventory ``aap_ca_bundle``) and ``verify_ssl`` in the persistent manager socket identity so a later task that changes trust policy spawns a distinct manager instead of reusing one with a stale trust store.
- authenticator_user - map the API ``provider`` field to ``authenticator`` so repeated moves are idempotent (https://issues.redhat.com/browse/AAP-38532).
- gateway_api lookup - Automatically read exported ``GATEWAY_HOSTNAME``, ``GATEWAY_USERNAME``, ``GATEWAY_PASSWORD``, ``GATEWAY_VERIFY_SSL``, ``GATEWAY_API_TOKEN``, and ``GATEWAY_REQUEST_TIMEOUT`` values, with supported ``AAP_*`` aliases as fallbacks. Explicit lookup options take precedence.
- process_manager - Fix vault credentials causing subprocess spawn failure when ``aap_username``, ``aap_password``, or ``aap_hostname`` are defined as Ansible Vault encrypted values. The manager subprocess spawn failed with ``TypeError expected str bytes or os.PathLike object not AnsibleVaultEncryptedUnicode`` because vault-encrypted values were not converted to ``str()`` before being passed to ``subprocess.Popen``. The issue was particularly visible when using token authentication while vaulted credentials existed in playbook variables.

v2.7.20260812
=============

Bugfixes
--------

- gateway_api - Update the lookup plugin to ensure the ephemeral manager processes getting spawned are terminated/killed.

v2.7.20260805
=============

Bugfixes
--------

- Add pkce_required parameter to application module as django-ansible-base added a pkce_required boolean field
- Add reject_failed_basic_auth route to prevent AuthenticationFailed exception during podman/docker login
- Change plugin hashing algorithm from md5 to sha256 for FIPS compliance

Documentation Changes
---------------------

- gateway_api - update documentation for the gateway_api lookup plugin to reflect the new functionality and usage. Additionally add and update examples.

v2.7.20260630
=============

Bugfixes
--------

- application - fix ``client_secret`` not returned in module result when creating a confidential OAuth application (https://issues.redhat.com/browse/AAP-80136).

v2.7.20260615
=============

Bugfixes
--------

- gateway_api lookup / search_api - Fix pagination for relative next URLs. AAP returns the next link as a relative path; it is now resolved against base_url with urljoin so absolute URLs are always requested.
- gateway_api lookup / search_api - Support Galaxy/Hub pagination envelope. Hub list responses use {meta, links, data} instead of the DRF {count, next, results} shape. return_all now handles both envelopes so /api/galaxy/ endpoints no longer silently return only the first page (backport of

v2.7.20260604
=============

Bugfixes
--------

- All modules - Fix aap_validate_certs alias resolution. When aap_validate_certs false was set via module_defaults or group/ansible.platform.gateway, it was silently ignored due to incorrect or-chaining in the config extractor. The parameter is now resolved using an explicit in-key check so that False is honoured correctly (AAP-75645).
- All modules - Fix empty-string handling for aap_request_timeout and gateway_request_timeout. The AAP built-in credential type injects aap_request_timeout as {{request_timeout}} which evaluates to empty string when not configured. Empty string caused argspec validation to fail with cannot be converted to float. Empty strings are now stripped before validation and the 10-second default is applied instead.
- All modules - Restore async/poll 0 parallelism for all ansible.platform action plugins. BaseResourceActionPlugin now sets _supports_async = True. All tasks always target localhost so Ansible's fork-based async mechanism works correctly, restoring the parallel execution that infra.aap_configuration gateway roles depend on and that was broken in the action plugin rewrite (AAP-76233).

v2.7.20260515
=============

Bugfixes
--------

- All modules - Fix task-level environment vars (e.g. SSL_CERT_FILE, REQUESTS_CA_BUNDLE, proxy settings) not being forwarded to the manager subprocess when using connection ansible.platform.http in direct or persistent mode. Previously forwarding only worked for connection local.
- All modules - Map SSL_CERT_FILE to REQUESTS_CA_BUNDLE automatically in the manager subprocess environment. The manager uses the requests library which reads REQUESTS_CA_BUNDLE not SSL_CERT_FILE; without this shim the containerized AAP installer SSL environment was silently ignored. SSL_CERT_FILE support is deprecated and will be removed in a future release.

v2.7.20260513
=============

Minor Changes
-------------

- Introduce new action plugin architecture with persistent manager process, RPC-based client, and versioned data model transformation layer. All modules now route through BaseResourceActionPlugin for consistent CRUD dispatch and idempotency handling.

Bugfixes
--------

- Strip scheme and hostname from AAP url builder, which previously lead to malformed urls in the ansible.platform.gateway_api lookup plugin (ACA-5393).
- application - Fix broken idempotency for redirect_uris and organization fields caused by list vs string and name vs integer FK type mismatches (AAP-73293).
- role_team_assignment - Fix deletion bug where assignments were not correctly removed when state absent was specified (AAP-73742).
- role_user_assignment - Raise a clear error when the specified role_definition or user does not exist on the Gateway rather than silently swallowing the failure (AAP-73741).
- role_user_assignment, role_team_assignment - Fix state exists returning a missing key error when no matching assignment was found (AAP-73294)

v1.0.0
======

