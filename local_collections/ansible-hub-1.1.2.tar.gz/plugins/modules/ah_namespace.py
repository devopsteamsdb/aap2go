#!/usr/bin/python
# -*- coding: utf-8 -*-

# Copyright: (c) 2020, Sean Sullivan <@sean-m-sullivan>
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)


DOCUMENTATION = """
---
module: ah_namespace
author:
    - Sean Sullivan (@sean-m-sullivan)
short_description: create, update, or destroy Automation Hub Namespace
description:
    - Create, update, or destroy Automation Hub Namespace.
options:
    name:
      description:
        - Namespace name.
        - Must be lower case containing only alphanumeric characters and underscores.
      required: True
      type: str
    new_name:
      description:
        - Setting this option will change the existing name (looked up via the name field).
      type: str
    description:
      description:
        - Description to use for the namespace.
      type: str
    company:
      description:
        - Namespace owner company name.
      type: str
    email:
      description:
        - Namespace contact email.
      type: str
    avatar_url:
      description:
        - Namespace logo URL.
      type: str
    resources:
      description:
        - Namespace resource page in Markdown format.
      type: str
    state:
      description:
        - Desired state of the resource.
      choices: ["present", "absent"]
      default: "present"
      type: str
    links:
      description:
        - A list of dictionaries of Name and url values for links related the Namespace.
      type: list
      elements: dict
      suboptions:
        name:
          description:
            - Link Text.
          type: str
          required: True
        url:
          description:
            - Link URL.
          type: str
          required: True
    groups:
      description:
        - A list of groups that have privileges on the Namespace.
      type: list
      elements: str
      default: []

extends_documentation_fragment: ansible.hub.auth
"""


EXAMPLES = """
- name: Create Hub Namespace template
  ansible.hub.ah_namespace:
    name: Redhat
    company: Redhat
    email: user@example.com
    avatar_url: https://pnt.redhat.com/pnt/d-11633955/LogoRedHatHatColorRGB.png
    description: This is the Redhat Namespace
    links:
      - name: "homepage"
        url: "https://www.redhat.com"
    groups:
      - system:partner-engineers
      - admins
"""

from ..module_utils.ah_module import AHModule


def main():
    # Any additional arguments that are not fields of the item can be added here
    argument_spec = dict(
        name=dict(required=True),
        new_name=dict(),
        description=dict(),
        company=dict(),
        email=dict(),
        avatar_url=dict(),
        resources=dict(),
        links=dict(type="list", elements="dict"),
        groups=dict(type="list", elements="str", default=[]),
        state=dict(choices=["present", "absent"], default="present"),
    )

    # Create a module for ourselves
    module = AHModule(argument_spec=argument_spec)

    # Extract our parameters
    name = module.params.get("name")
    new_name = module.params.get("new_name")
    state = module.params.get("state")

    new_fields = {}

    # Attempt to look up an existing item based on the provided data
    existing_item = module.get_one("namespaces", name_or_id=name)

    if state == "absent":
        # If the state was absent we can let the module delete it if needed, the module will handle exiting from this
        module.delete_if_needed(existing_item)

    # Create the data that gets sent for create and update
    # Remove these two comments for final
    # Check that Links and groups works with this.
    if new_name:
        new_fields["name"] = new_name
    elif existing_item:
        new_fields["name"] = module.get_item_name(existing_item)
    else:
        new_fields["name"] = name

    for field_name in (
        "description",
        "company",
        "email",
        "avatar_url",
        "resources",
        "links",
    ):
        field_val = module.params.get(field_name)
        if field_val is not None:
            new_fields[field_name] = field_val

    # Backwards compatibility for older versions of AH
    groups = module.params.get("groups")
    new_fields["groups"] = []
    if groups:
        for group in groups:
            new_fields["groups"].append(
                {
                    "name": group,
                    "object_permissions": ["change_namespace", "upload_to_namespace"],  # Old style of group object
                    "object_roles": ["galaxy.collection_namespace_owner"],  # New style of group object
                }
            )

    # If the state was present and we can let the module build or update the existing item, this will return on its own
    module.create_or_update_if_needed(
        existing_item,
        new_fields,
        endpoint="namespaces",
        item_type="namespaces",
    )


if __name__ == "__main__":
    main()
